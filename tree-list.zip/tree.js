const API = "http://localhost/tree-list/getdata.php";
function treeBuilder(parent, node) {
    axios.get(API + "?parent=" + parent).then(
        result => {
            let dataset = result.data;
            if (dataset === null || !dataset) return false;
            if (document.getElementById(node)) {
                document.getElementById(node).innerHTML += dataset;
                document.getElementById('ptxPluss').addEventListener('click', function () {
                    let itemArr = document.getElementsByClassName('ptx_last_child');
                    for (const item of itemArr) {
                        let dataID = item.dataset.id;
                        if (dataID) {
                            let idElement = 'treeSub-' + dataID;
                            treeBuilder(dataID, idElement);
                        }
                    }
                    let clerElm = document.querySelectorAll('.ptx_last_child');
                    for (let index = 0; index < clerElm.length; index++) {
                        const element = clerElm[index];
                        element.classList.remove('ptx_last_child');
                    }
                });
            }
        }
    )
}
treeBuilder(0, 'ptxtreelist');