<?php
    header('Access-Control-Allow-Origin: *');
    error_reporting(0);
    require "data.php";
    global $PTX_MAKE_DATA;
//    if($_GET['parent']){
//        echo $PTX_MAKE_DATA->buildTree($_GET['parent']);
//    }else{
//        echo $PTX_MAKE_DATA->buildTree(0);
//    }
    echo $PTX_MAKE_DATA->buildTreeRoot(5,"sss");
